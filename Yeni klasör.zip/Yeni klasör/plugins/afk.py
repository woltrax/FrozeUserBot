from bot import bot
from telethon import events
import time

afk_status = False
afk_message = "🤖 Sahibim şu an aktif değil. \n Aktif olunca dönüt verecektir. \nBen FROZE UserBot sahibimi korumakla görevliyim"
afk_start_time = 0
afk_logs = []

@bot.on(events.NewMessage(pattern='/afk(?: (.*))?'))
async def set_afk(event):
    global afk_status, afk_message, afk_start_time, afk_logs
    msg = event.pattern_match.group(1)
    afk_status = True
    afk_logs = []
    afk_start_time = time.time()
    if msg:
        afk_message = msg
        await event.reply(f"🕒 AFK mesajınız ayarlandı:\n{afk_message}")
    else:
        await event.reply("🕒 AFK moduna geçildi. Varsayılan mesaj gönderilecek.")

@bot.on(events.NewMessage(pattern='/back'))
async def remove_afk(event):
    global afk_status, afk_logs
    afk_status = False
    summary = "✅ AFK modu kapatıldı."
    if afk_logs:
        summary += f"\n🧾 {len(afk_logs)} kişi seni yokluğunda aradı:"
        for i, (sender, msg) in enumerate(afk_logs, 1):
            summary += f"\n{i}. {sender}: {msg}"
    else:
        summary += "\nKimse seni aramadı. 🫢"
    afk_logs = []
    await event.reply(summary)

@bot.on(events.NewMessage())
async def auto_afk_reply(event):
    global afk_status, afk_message, afk_start_time, afk_logs
    if afk_status and not event.out:
        duration = int(time.time() - afk_start_time)
        minutes = duration // 60
        seconds = duration % 60
        since = f"{minutes} dk {seconds} sn önce"
        reply_text = f"{afk_message}\n\n📆 AFK olalı: {since}"
        sender = (await event.get_sender()).first_name
        afk_logs.append((sender, event.message.message))
        await event.reply(reply_text)